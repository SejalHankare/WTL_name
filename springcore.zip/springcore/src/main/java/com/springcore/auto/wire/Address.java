package com.springcore.auto.wire;

public class Address {

}
