package com.springcore.ci;

public class Certificate {
	
	 String name;
	Certificate(String name)
	{
		this.name=name;
	}
	public String toString()
	{
		return this.name;
	}

}
