package com.tut;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmDemo {
	
	public static void main(String args[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory  factory=cfg.buildSessionFactory();
		Student student1= new Student();
		student1.setId(121);
		student1.setName("Sejal");
		student1.setCity("Pune");
		
		Certificate certificate= new Certificate();
		certificate.setCourse("Android");
		certificate.setDuration("6 month");
		student1.setCerti(certificate);
		
		
		
		Student student2= new Student();
		student2.setId(122);
		student2.setName("lavnya");
		student2.setCity("Mumbai");
		
		Certificate certificate1= new Certificate();
		certificate1.setCourse("web dveloper");
		certificate1.setDuration("3 month");
		student2.setCerti(certificate1);
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(student1);
		session.save(student2);
		 
		tx.commit();
		session.close();
		factory.close();
	}

}
